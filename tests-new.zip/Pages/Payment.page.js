import {test,expect} from '@playwright/test'

exports.Payment = class Payment {
    
    constructor(page){
        this.page=page;

        this.PaymentText = page.locator('ol')
        this.PaymentPageHeading=page.getByRole('heading', { name: 'Payment' })
        this.CardNameText= page.getByText('Name on Card')
        this.CardNumberText = page.getByText('Card Number')
        this.CardCVCText=page.getByText('CVC')
        this.CardExpirationText=page.getByText('Expiration')

        this.CardCVCPlaceholderText = page.getByPlaceholder('ex.')
        this.CardMonthPlaceholderText = page.getByPlaceholder('MM')
        this.CardYearPlaceholderText=  page.getByPlaceholder('YYYY')
        this.ConfirmPlaceholderText = page.getByRole('button', { name: 'Pay and Confirm Order'})    

        this.CardNameInput = page.locator('input[name="name_on_card"]')
        this.CardNumberInput = page.locator('input[name="card_number"]')
        this.CardCVCInput = page.getByPlaceholder('ex.')
        this.CardMMInut= page.getByPlaceholder('MM')
        this.CardYearInput= page.getByPlaceholder('YYYY')
        
    }
    
}

//Payment Page
await expect(page.locator('ol')).toContainText('Payment');
//await expect(page.locator('li').filter({ hasText: 'Payment' })).toBeVisible();
await expect(page.getByRole('heading', { name: 'Payment' })).toBeVisible();
//await expect(page.locator('#cart_items')).toContainText('Payment');
await expect(page.getByText('Name on Card')).toBeVisible();
//await expect(page.locator('#payment-form')).toContainText('Name on Card');
await expect(page.getByText('Card Number')).toBeVisible();
//await expect(page.locator('#payment-form')).toContainText('Card Number');
await expect(page.getByText('CVC')).toBeVisible();
//await expect(page.locator('#payment-form')).toContainText('CVC');
await expect(page.getByText('Expiration')).toBeVisible();
//await expect(page.locator('#payment-form')).toContainText('Expiration');
await expect(page.getByPlaceholder('ex.')).toBeVisible();
await expect(page.getByPlaceholder('MM')).toBeVisible();
await expect(page.getByPlaceholder('YYYY')).toBeVisible();
await expect(page.getByRole('button', { name: 'Pay and Confirm Order' })).toBeVisible();
await page.getByRole('button', { name: 'Pay and Confirm Order' }).click();
await page.locator('input[name="name_on_card"]').click();
await page.locator('input[name="name_on_card"]').fill('gjgjw');
await page.locator('input[name="card_number"]').click();
await page.locator('input[name="card_number"]').fill('634726327');
await page.getByPlaceholder('ex.').click();
await page.getByPlaceholder('ex.').fill('222');
await page.getByPlaceholder('MM').click();
await page.getByPlaceholder('MM').fill('01');
await page.getByPlaceholder('YYYY').click();
await page.getByPlaceholder('YYYY').fill('2022');
await page.getByRole('button', { name: 'Pay and Confirm Order' }).click();

//await expect(page.locator("div[class='single-widget'] h2")).toBeVisible()
await expect(page.getByText('Order Placed!')).toBeVisible();
await expect(page.locator('#form')).toContainText('Order Placed!');
await expect(page.getByText('Order Placed!')).toBeVisible();
await expect(page.locator('#form')).toContainText('Congratulations! Your order has been confirmed!');
await expect(page.getByRole('link', { name: 'Download Invoice' })).toBeVisible();
await expect(page.locator('#form')).toContainText('Download Invoice');
await expect(page.getByRole('link', { name: 'Continue' })).toBeVisible();
await expect(page.locator('#form')).toContainText('Continue');
await page.getByRole('link', { name: 'Continue' }).click();
await page.locator('div').filter({ hasText: 'Home  Products Cart Logout' }).nth(2).click();
await expect(page.locator('div').filter({ hasText: 'Home  Products Cart Logout' }).nth(2)).toBeVisible();

